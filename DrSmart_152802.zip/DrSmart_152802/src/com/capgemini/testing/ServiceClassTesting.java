package com.capgemini.testing;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.capgemini.doctors.service.DoctorAppointmentService;

import junit.framework.Assert;

public class ServiceClassTesting {

	@Test
	public void testValidatePhoneNo() {
		DoctorAppointmentService check = new DoctorAppointmentService();
	
	assertEquals(true, check.validatePhoneNumber("9874563210"));
		
	}
	
	@Test
	public void testValidateName() {
		DoctorAppointmentService check = new DoctorAppointmentService();
	
	assertEquals(true, check.validateName("Peter"));
		
	}
	
	@Test
	public void testValidateNameFail() {
		DoctorAppointmentService check = new DoctorAppointmentService();
	
	assertEquals(false, check.validateName("s@mpauL"));
		
	}

	@Test
	public void testValidateAge()
	{
		DoctorAppointmentService check = new DoctorAppointmentService();
		assertEquals(true, check.validateAge(34));
	}
	
	@Test
	public void testValidateEmailPass()
	{
		DoctorAppointmentService check = new DoctorAppointmentService();
		assertEquals(true, check.validateEmail("abc123@gmail.com"));
	}
	@Test
	public void testValidatePhoneNoFail() {
		DoctorAppointmentService check = new DoctorAppointmentService();
	
	assertEquals(false, check.validatePhoneNumber("8745621212121"));
		
	}
	
	@Test
	public void testValidateNameFail2() {
		DoctorAppointmentService check = new DoctorAppointmentService();
	
	assertEquals(false, check.validateName("Matt123"));
		
	}
	
	

	@Test
	public void testValidateAgeFail()
	{
		DoctorAppointmentService check = new DoctorAppointmentService();
		assertEquals(false, check.validateAge(152));
	}
}
