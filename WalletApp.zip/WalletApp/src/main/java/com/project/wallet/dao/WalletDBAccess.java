package com.project.wallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;

import com.project.wallet.bean.Account;
import com.project.wallet.exception.WalletException;
import com.project.wallet.util.DBUtil;

public class WalletDBAccess implements IWalletAccess {
Connection con = DBUtil.getConnect();

	@Override
	public int accCreation(Account a) throws WalletException  {
		a.setAccNum();
		a.settDetails("Initial Balance : "+a.getCustBal());
String sql1 = "INSERT INTO ACCOUNT VALUES(?,?,?,?,?,?)";
String sql2 = "INSERT INTO TDETAILS VALUES(?,?)";
PreparedStatement pstmt;
try {
	pstmt = con.prepareStatement(sql1);
	pstmt.setInt(1, a.getAccNum());
	pstmt.setString(2, a.getCustName());
	pstmt.setString(3, a.getCustPhoneNo());
	pstmt.setInt(4, a.getCustAge());
	pstmt.setDouble(5, a.getCustBal());
	pstmt.setString(6, a.getCustPwd());


	int row = pstmt.executeUpdate();
	if(row>0) {
		
		System.out.println("***********************");
	}
	
	pstmt = con.prepareStatement(sql2);
	pstmt.setInt(1, a.getAccNum());
	pstmt.setString(2, a.gettDetails());
	
	int row1 = pstmt.executeUpdate();
	if(row1>0)
	{
		System.out.println("1 row has been inserted successfully");
	}
} catch (SQLException e) {
	
	e.printStackTrace();
}



		return a.getAccNum();
	}

	@Override
	public Account loginUser(int accNo) throws WalletException {

String sql1 = "SELECT * FROM ACCOUNT WHERE CUSTID =?";
try {
	
	
	PreparedStatement pstmt = con.prepareStatement(sql1);
	pstmt.setInt(1, accNo);
	
	ResultSet rslt = pstmt.executeQuery();
	if(rslt.next()) {
		
		Account tempLogin = new Account();
		tempLogin.setCustName(rslt.getString(2));
		tempLogin.setCustAge(rslt.getInt(4));
		tempLogin.setCustBal(rslt.getDouble(5));
		tempLogin.setCustPhoneNo(rslt.getString(3));
		tempLogin.setCustPwd(rslt.getString(6));
		
		
		
		return tempLogin;
		
		
	}
	
	
	
} catch (SQLException e) {
	throw new WalletException("DB fetch error");
}



		return null;
	}

	@Override
	public void updateDetails(int accNo, Account a) throws WalletException {
		
		String sql1 = "UPDATE ACCOUNT SET CUSTBAL=? WHERE CUSTID =?";
		String sql2 = "INSERT INTO TDETAILS VALUES(?,?)";
		PreparedStatement pstmt;
		try {
			 pstmt = con.prepareStatement(sql1);
			pstmt.setDouble(1, a.getCustBal());
		
			pstmt.setInt(2, accNo);
			int row = pstmt.executeUpdate();
			if(row>0)
			{
				System.out.println("*********************");
			}
			pstmt = con.prepareStatement(sql2);
			pstmt.setInt(1, accNo);
			pstmt.setString(2, a.gettDetails());
			int row1 = pstmt.executeUpdate();
			if(row1>0) {
				
				System.out.println("updated successfully");
			}
			
		} catch (SQLException e) {
			throw new WalletException("Update Details Failed");
		}
		
		
	}
	
	public Stack<String> getTransactionDetails(int accNo) throws WalletException
	{
		String sql2 = "SELECT DETAILS FROM TDETAILS WHERE CUSTID=?";
		Stack<String> rsltList = new Stack<String>();
	
		try {
			PreparedStatement pstmt = con.prepareStatement(sql2);
			pstmt.setInt(1, accNo);
			ResultSet rslt = pstmt.executeQuery();
			
			
			while(rslt.next()) {
			
				
		rsltList.push(rslt.getString(1));
				
			
			}
			
		} catch (SQLException e) {
			throw new WalletException("Transaction Details Error");
		}
		
		
		return rsltList;
	}
	
	
	

}
