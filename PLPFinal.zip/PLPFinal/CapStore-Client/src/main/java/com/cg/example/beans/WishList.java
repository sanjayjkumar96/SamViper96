package com.cg.example.beans;

import java.util.List;


public class WishList 
{
	
	private int wishId;
	
	
	private List<Product> product;

	

	

	public int getWishId() {
		return wishId;
	}

	public void setWishId(int wishId) {
		this.wishId = wishId;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public WishList(int wishId, List<Product> product) {
		super();
		this.wishId = wishId;
		this.product = product;
	}

	public WishList() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "WishList [id=" + wishId + ", product=" + product + "]";
	}

	
	
	
}
