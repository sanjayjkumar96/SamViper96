package com.cg.example.service;

import org.springframework.stereotype.Service;

@Service
public interface ProductService {

	public boolean checkQuantity(int id);
}
