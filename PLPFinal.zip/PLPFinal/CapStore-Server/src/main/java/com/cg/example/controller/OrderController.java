package com.cg.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.example.beans.OrderDetails;
import com.cg.example.service.OrderService;
import com.cg.example.service.ProductService;

@RestController
public class OrderController {

@Autowired
private OrderService oService;

@Autowired
private ProductService pService;

public OrderService getoService() {
	return oService;
}

public void setoService(OrderService oService) {
	this.oService = oService;
}

public ProductService getpService() {
	return pService;
}

public void setpService(ProductService pService) {
	this.pService = pService;
}


@RequestMapping(value = "/placeOrder")
public OrderDetails placeOrder(@RequestBody OrderDetails order)
{
	boolean checkFlag = pService.checkQuantity(order.getId());
	if(checkFlag == true)
	return oService.saveOrder(order);
	order.setStatus("Failed to Place Order");
	return order;
}
	
@RequestMapping(value = "/successOrder")
public OrderDetails successDelivery(@RequestBody OrderDetails order)
{
	order.setStatus("Delivered");
	return oService.saveOrder(order);
}
}
