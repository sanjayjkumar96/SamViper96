package com.project.wallet.dao;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.project.wallet.bean.Account;
import com.project.wallet.exception.WalletException;
@Repository
public class WalletDBAccess implements IWalletAccess {


private JdbcTemplate con;

	public void setCon(JdbcTemplate con) {
	this.con = con;
}

	@Override
	public int accCreation(Account a) throws WalletException  {
		a.setAccNum();
		a.settDetails("Initial Balance : "+a.getCustBal());
String sql1 = "INSERT INTO ACCOUNT VALUES("+a.getAccNum()+","+a.getCustName()+","+a.getCustPhoneNo()+","
+a.getCustAge()+","+a.getCustBal()+","+a.getCustPwd()+")";
String sql2 = "INSERT INTO TDETAILS VALUES("+a.getAccNum()+","+a.gettDetails()+")";

try {
	
	

	int row = con.update(sql1);
	if(row>0) {
		
		System.out.println("***********************");
	}
	
	
	
	int row1 = con.update(sql2);
	if(row1>0)
	{
		System.out.println("1 row has been inserted successfully");
	}
} catch (DataAccessException e) {
	
	e.printStackTrace();
}



		return a.getAccNum();
	}

	@Override
	public Account loginUser(int accNo) throws WalletException {

String sql1 = "SELECT * FROM ACCOUNT WHERE CUSTID ="+accNo;
try {
	
	Account tempLogin = new Account();

	tempLogin = con.queryForObject(sql1, Account.class);
	/*if(rslt.next()) {
		
		
		tempLogin.setCustName(rslt.getString(2));
		tempLogin.setCustAge(rslt.getInt(4));
		tempLogin.setCustBal(rslt.getDouble(5));
		tempLogin.setCustPhoneNo(rslt.getString(3));
		tempLogin.setCustPwd(rslt.getString(6));
		}*/
		
		
		return tempLogin;
		
		
	
	
	
	
} catch (DataAccessException e) {
	throw new WalletException("DB fetch error");
}

	}

	@Override
	public void updateDetails(int accNo, Account a) throws WalletException {
		
		String sql1 = "UPDATE ACCOUNT SET CUSTBAL="+a.getCustBal()+" WHERE CUSTID ="+accNo;
		String sql2 = "INSERT INTO TDETAILS VALUES("+accNo+","+a.gettDetails()+")";
	
		try {
			
		
			int row = con.update(sql1);
			if(row>0)
			{
				System.out.println("*********************");
			}
			
			int row1 = con.update(sql2);
			if(row1>0) {
				
				System.out.println("updated successfully");
			}
			
		} catch (DataAccessException e) {
			throw new WalletException("Update Details Failed");
		}
		
		
	}
	
	public List<String> getTransactionDetails(int accNo) throws WalletException
	{
		String sql2 = "SELECT DETAILS FROM TDETAILS WHERE CUSTID="+accNo;
		List<String> rsltList = null;
	
		try {
			
		 rsltList = con.queryForList(sql2,String.class);
			
			
			
			
		} catch (DataAccessException e) {
			throw new WalletException("Transaction Details Error");
		}
		
		
		
		return rsltList;
	}
	
	
	

}
