package com.cg.example.service;

import com.cg.example.beans.OrderDetails;

public interface OrderService {
	

	

	OrderDetails saveOrder(OrderDetails order);	
}
