package com.cg.example.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.example.beans.OrderDetails;
import com.cg.example.repo.OrderRepo;

public class OrderServiceImpl implements OrderService {

	@Autowired
	private OrderRepo oRepo;
	
	
	
	



	public OrderRepo getoRepo() {
		return oRepo;
	}





	public void setoRepo(OrderRepo oRepo) {
		this.oRepo = oRepo;
	}


	@Override
	public OrderDetails saveOrder(OrderDetails order) {
		
		
		return oRepo.save(order);
	}


	
	
}
