package com.project.wallet.bean;

import java.io.Serializable;
import java.util.ArrayList;

public class Account {
	
	private int accNum;
	private String custName;
	private String custPhoneNo;
	private int custAge;
	private double custBal;

	private String custPwd;
	String tDetails = new String();
	public String gettDetails() {
		return tDetails;
	}
	public void settDetails(String getDetails) {
		this.tDetails = getDetails;
	}
	public int getAccNum() {
		return accNum;
	}
	public void setAccNum() {
		 int max =1000,min =999;
		 this.accNum = (int) ((max-min)*min*Math.random());
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustPhoneNo() {
		return custPhoneNo;
	}
	public void setCustPhoneNo(String custPhoneNo) {
		this.custPhoneNo = custPhoneNo;
	}
	public int getCustAge() {
		return custAge;
	}
	public void setCustAge(int custAge) {
		this.custAge = custAge;
	}
	public double getCustBal() {
		return custBal;
	}
	public void setCustBal(double custBal) {
		this.custBal = custBal;
	}
	public String getCustPwd() {
		return custPwd;
	}
	public void setCustPwd(String custPwd) {
		this.custPwd = custPwd;
	}
	
	
	
	

}
