package com.cg.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.example.beans.Customer;
public interface CartCustomer extends JpaRepository<Customer, Integer> {  
}  