package com.cg.example.service;

import org.springframework.web.bind.annotation.RequestBody;

import com.cg.example.beans.Discount;
import com.cg.example.beans.Product;

public interface ApplyDiscountInterface {

	public Product discountDB(int id, @RequestBody Discount discount);
}
