package com.cg.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.example.beans.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {
	
	

}
