package com.cg.example.service;

import java.sql.Date;
import java.time.LocalDate;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.example.beans.Discount;
import com.cg.example.beans.Product;
import com.cg.example.repo.DiscountRepo;
import com.cg.example.repo.DiscountRepo2;

@Service
public class ApplyDiscountImpl implements ApplyDiscountInterface {
	@Autowired
	DiscountRepo repo;
	@Autowired
	DiscountRepo2 repo2;

	@Override
	public Product discountDB(int id, Discount discount) {
		Product product = repo2.getOne(id);
		discount.setStartTime(Date.valueOf(LocalDate.now()));
		discount = repo.save(discount);
		
		repo2.save(product);
		return product;
	}

}
