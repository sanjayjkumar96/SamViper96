package com.cg.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.example.beans.Product;

public interface CartProductRepository extends JpaRepository<Product, Integer> {

}
