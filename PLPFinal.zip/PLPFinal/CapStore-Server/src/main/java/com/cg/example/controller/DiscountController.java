package com.cg.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.example.beans.Discount;
import com.cg.example.beans.Product;
import com.cg.example.service.ApplyDiscountInterface;

@RestController
public class DiscountController {
	@Autowired
	ApplyDiscountInterface service;

	@RequestMapping(value = "/discountDB", method = RequestMethod.POST)
	public Product discountDB(int id, @RequestBody Discount discount) {
		return service.discountDB(id, discount);
		
	}

}
