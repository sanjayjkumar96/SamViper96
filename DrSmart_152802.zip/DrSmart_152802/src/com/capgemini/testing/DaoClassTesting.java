package com.capgemini.testing;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.DrSmartException;

import junit.framework.Assert;

public class DaoClassTesting {

	private static final String Expected = null;

	@Test
	public void testAddPatientDetials() {
		
		DoctorAppointment checkObj = new DoctorAppointment();
		
		DoctorAppointmentDao checkMethod = new DoctorAppointmentDao();
		checkObj.setPatientName("Sam");
		checkObj.setPhoneNumber("9874563210");
		checkObj.setAge(21);
		checkObj.setEmail("abc123@gmail.com");
		checkObj.setGender("male");
		checkObj.setProblemName("Heart");
		int tempA = checkMethod.addDoctorAppoinmtmentDetails(checkObj);
		int tempE = checkObj.getAppointmentId();
		Assert.assertEquals(tempE,tempA );
	
		
		
	}

	@Test
	public void testAddPatientDetialsFail() {
		
		DoctorAppointment checkObj = new DoctorAppointment();
		DoctorAppointment checkObj1 = new DoctorAppointment();
		DoctorAppointmentDao checkMethod = new DoctorAppointmentDao();
		checkObj.setPatientName("Sam");
		checkObj.setPhoneNumber("9874563210");
		checkObj.setAge(21);
		checkObj.setEmail("abc123@gmail.com");
		checkObj.setGender("male");
		checkObj.setProblemName("Heart");
		int tempA = checkMethod.addDoctorAppoinmtmentDetails(checkObj1);
		int tempE = checkObj.getAppointmentId();
		Assert.assertEquals(tempE,tempA);
	
	}
	
	@Test
	public void testViewDetails() throws DrSmartException {
		
		DoctorAppointment checkObj = new DoctorAppointment();
		
		DoctorAppointmentDao checkMethod = new DoctorAppointmentDao();
		
		DoctorAppointment checkObj1 = checkMethod.getDoctorAppointmentDetails(checkMethod.addDoctorAppoinmtmentDetails(checkObj));
		Assert.assertEquals(checkObj,checkObj1);
	
	}
	
	@Test(expected  = DrSmartException.class)
	public void testViewDetailsExceptionPass() throws DrSmartException  {
		
		DoctorAppointment checkObj = new DoctorAppointment();
		
		DoctorAppointmentDao checkMethod = new DoctorAppointmentDao();
		
		checkMethod.getDoctorAppointmentDetails(1122);
		
	
	}
	@Test(expected  = DrSmartException.class)
	public void testViewDetailsExceptionFail() throws DrSmartException  {
		
		DoctorAppointment checkObj = new DoctorAppointment();
		
		DoctorAppointmentDao checkMethod = new DoctorAppointmentDao();
		
		checkMethod.getDoctorAppointmentDetails(checkMethod.addDoctorAppoinmtmentDetails(checkObj));
		
	
	}
}
