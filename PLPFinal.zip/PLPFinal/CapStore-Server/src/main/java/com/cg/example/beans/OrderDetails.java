package com.cg.example.beans;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"})
@Entity
public class OrderDetails 
{
	
	  @Id
	  @GeneratedValue(strategy = GenerationType.AUTO)
	  int id;
		
	  String status;
	  
	  float amount;
	  
	  int quantity;
	  
	  @OneToOne()
	  Customer customer;
	  
	  
	  @ManyToMany()
	  List<Product> product;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}


	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public float getAmount() {
		return amount;
	}

	public void setAmount(float amount) {
		this.amount = amount;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product.add(product);
	}


	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderDetails(int id, String status, float amount, int quantity, Customer customer, List<Product> product) {
		super();
		this.id = id;
		this.status = status;
		this.amount = amount;
		this.quantity = quantity;
		this.customer = customer;
		this.product = product;
	}

	@Override
	public String toString() {
		return "OrderDetails [id=" + id + ", status=" + status + ", amount=" + amount + ", quantity=" + quantity
				+ ", customer=" + customer + ", product=" + product + "]";
	}

	  
	  
}
