package com.cg.example.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.example.beans.Discount;

public interface DiscountRepo  extends JpaRepository<Discount,Integer>{
	
	

}
