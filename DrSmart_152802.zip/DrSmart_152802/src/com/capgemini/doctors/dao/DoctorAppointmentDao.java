package com.capgemini.doctors.dao;


import java.util.TreeMap;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DrSmartException;

public class DoctorAppointmentDao implements IDoctorAppointmentDao{

	TreeMap<Integer,DoctorAppointment> appointments = new TreeMap<Integer,DoctorAppointment>();
	
	@Override
	public int addDoctorAppoinmtmentDetails(DoctorAppointment doctorAppointment) {
		doctorAppointment.setAppointmentId();
		appointments.put(doctorAppointment.getAppointmentId(),doctorAppointment);
		return doctorAppointment.getAppointmentId();
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws DrSmartException {
		if(appointments.containsKey(appointmentId))
		{
			return appointments.get(appointmentId);
		}
		else
			throw new DrSmartException("No appointments Found :(");
	}

}
