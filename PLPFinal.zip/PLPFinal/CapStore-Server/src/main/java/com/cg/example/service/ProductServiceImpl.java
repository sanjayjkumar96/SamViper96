package com.cg.example.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.example.beans.Product;
import com.cg.example.repo.ProductRepo;

public class ProductServiceImpl implements ProductService {

	@Autowired
	private ProductRepo repo;
	
	
	
	public ProductRepo getRepo() {
		return repo;
	}



	public void setRepo(ProductRepo repo) {
		this.repo = repo;
	}



	@Override
	public boolean checkQuantity(int id) {
		Product temp = repo.getOne(id);
		if(temp.getQuantity()>0)
		return true;
		else
			return false;
	}

}
