package com.cg.example.beans;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class WishList 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int wishId;
	
	@OneToMany(cascade = CascadeType.ALL)
	private List<Product> product;

	

	

	public int getWishId() {
		return wishId;
	}

	public void setWishId(int wishId) {
		this.wishId = wishId;
	}

	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public WishList(int wishId, List<Product> product) {
		super();
		this.wishId = wishId;
		this.product = product;
	}

	public WishList() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "WishList [id=" + wishId + ", product=" + product + "]";
	}

	
	
	
}
