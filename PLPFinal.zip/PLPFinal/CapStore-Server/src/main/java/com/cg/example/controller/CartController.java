package com.cg.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.example.beans.Cart;
import com.cg.example.beans.Product;
import com.cg.example.service.ICartService;

@RestController
public class CartController {
	
	@Autowired
	ICartService service;
	
	@RequestMapping(value="/addCartItem")
	public Product addProduct(int pid,int cid)
	{
		return service.addCartItem(pid,cid);
	}
	@RequestMapping(value="/removeCartItem")
	public void delProduct(int pid,int cid)
	{
		 service.removeCartItem(pid,cid);
	}
	@RequestMapping(value="/addCart")
	public void addProduct(int cid)
	{
		service.addCart(cid);
	}
	@RequestMapping(value="/viewCart")
	public Cart viewCart(int cid)
	{
		return service.viewCart(cid);
	}
	@RequestMapping(value="/minAmountCheck")
	public Boolean amountCheck(int cid)
	{
		return service.minAmountCheck(cid);
	}

	

}
