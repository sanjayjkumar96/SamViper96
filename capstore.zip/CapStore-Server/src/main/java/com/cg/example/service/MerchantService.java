package com.cg.example.service;

import org.springframework.stereotype.Service;

import com.cg.example.beans.Merchant;
@Service
public interface MerchantService {

	public Merchant merchantSignUp(Merchant merchant);

	public Merchant findMerchant(Merchant merchant);

}
