package com.capgemini.doctors.ui;

import java.util.Scanner;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.exception.DrSmartException;
import com.capgemini.doctors.service.DoctorAppointmentService;

public class Client {
	
	public static void main(String[] args) {
		
		boolean nameFlag = false,phoneNoFlag = false,emailFlag = false,ageFlag = false,genderFlag = false;
		String name,phoneNo,email,gender,problemName;
		int age,choice,appointmentId;
		Scanner get = new Scanner(System.in);
		DoctorAppointmentService service = new DoctorAppointmentService();
		
		do {
			System.out.println("\n************* DrSmart Service *************");
			System.out.println("Choose an operation");
			System.out.println("1. Book Doctor Appointment");
			System.out.println("2. View Doctor Appointment");
			System.out.println("3. Exit");
			System.out.println("******************************");
			System.out.print("\nPlease Enter a Choice : ");
			choice = get.nextInt();
			System.out.println("\n******************************");
			switch(choice)
			{
			
			
				case 1 :// Creating a new Account for the user
					{
						
						//customer name
						do
						{
							System.out.println("Enter the name of the Patient :");
							name=get.next();
							nameFlag=service.validateName(name);
							if(nameFlag==false)
								System.out.println("Name should be entered in proper format(eg.Robert)");
							
						}while(nameFlag==false);
						
						//Customer Phone Number
						do
						{
							System.out.println("Enter phone number : ");
							phoneNo = get.next();
							phoneNoFlag = service.validatePhoneNumber(phoneNo);
							if(phoneNoFlag==false)
								System.out.println("Phone number should be of 10 digits");
						}while(phoneNoFlag==false);
						
						//getting email id
						do
						{
							System.out.println("Enter Email ID : ");
							email = get.next();
							emailFlag = service.validateEmail(email);
							if(emailFlag==false)
								System.out.println("Email Id should be in proper format eg: abc123@gmail.com");
						}while(emailFlag==false);
				
						//Customer Age
						do
						{
						System.out.println("Enter Age : ");
						
						age = get.nextInt();
						ageFlag= service.validateAge(age);
						if(ageFlag==false)
							System.out.println("Age should be below 110");
						
						}while(ageFlag==false);
						
						
						//getting gender of the patient
						do
						{
							System.out.println("Enter Gender : ");
							gender = get.next();
							try {
								genderFlag = service.validateGender(gender);
							} catch (DrSmartException e) {
								System.out.println(e.getMessage());
							}
							if(genderFlag==false)
								System.out.println("Incorrect Value");
						}while(genderFlag==false);
						
						
						//getting the problem name of the patient
						
						System.out.println("Enter the Problem Name :");
						problemName = get.next();
						
						
						//setting the values
						
						DoctorAppointment newPatient = new DoctorAppointment();
						newPatient.setPatientName(name);
						newPatient.setAge(age);
						newPatient.setPhoneNumber(phoneNo);
						newPatient.setGender(gender);
						newPatient.setEmail(email);
						newPatient.setProblemName(problemName);
						appointmentId = service.addDoctorAppoinmtmentDetails(newPatient);
						System.out.println("Your Doctor Appointment has been successfully registered,\nYour appointment ID is :"+appointmentId);
					
						break;
		}
					
				case 2:
				{
					//pwdFlag = false;
					System.out.println("\n************* DrSmart Service *************");
					System.out.println("Enter the Appointment ID :");
					//logic for user id check;
					appointmentId = get.nextInt();
					try {
						DoctorAppointment temp = service.getDoctorAppointmentDetails(appointmentId);
						
						System.out.println("\n************* DrSmart Service *************");
						System.out.println("Patient Name :"+temp.getPatientName());
						System.out.println("Appointment Status :"+temp.getAppointementStatus());
						System.out.println("Doctor Name:"+temp.getDoctorName());
						System.out.println("******************************");
						System.out.print("Appointment Date and time, along with doctor's phone number \n will be shared shortly with you.");
						System.out.println("\n******************************");
						
						
						
						
					} catch (DrSmartException e) {
						
						System.out.println(e.getMessage());
					}
					
					
				break;	
	}
				
				case 3:
					System.out.println("Thank You");
					System.exit(0);
					break;
				
				
				}
			System.out.print("Do you want to continue? 1-Yes  0 - No : ");
				
				choice = get.nextInt();
			}while(choice==1);
		
		
		
	}

}
