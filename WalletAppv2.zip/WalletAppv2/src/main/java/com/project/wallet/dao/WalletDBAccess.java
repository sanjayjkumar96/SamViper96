package com.project.wallet.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.project.wallet.entity.Account;
import com.project.wallet.entity.TDetails;
import com.project.wallet.exception.WalletException;

public class WalletDBAccess implements IWalletDBAccess {
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager manager;
	public int accCreation(Account a) throws WalletException {
		
		try {
		 manager = factory.createEntityManager();
		manager.getTransaction().begin();
		manager.persist(a);
		manager.getTransaction().commit();
		manager.close();
		return a.getAccNum();}
		catch (Exception e) {
			throw new WalletException("Insertion error");
		}
	}

	public Account loginUser(int accNo) throws WalletException {
	
		try{
			manager = factory.createEntityManager();
		
		
		Account tempLogin =new Account();
		tempLogin = manager.find(Account.class, accNo);
		
		
		manager.close();
		return tempLogin;
		}
		catch (Exception e) {
			throw new WalletException("Login Check error");
		}
	}

	public void updateDetails(int accNo, Account a) throws WalletException {
		try{
			
			manager = factory.createEntityManager();
		
		manager.getTransaction().begin();
	
		manager.merge(a);
		manager.getTransaction().commit();
		manager.close();
		}
		catch (Exception e) {
			throw new WalletException("Updation problem");
		}
		
	}

	public List<TDetails> fetchTransaction(int accNum) throws WalletException {
		manager = factory.createEntityManager();
		List<TDetails> list = new ArrayList<TDetails>();
		TypedQuery<TDetails> query = manager.createNamedQuery("getTDetails", TDetails.class);
		query.setParameter("id", accNum);
		list = query.getResultList();
		manager.close();
		return list;
	}

}
