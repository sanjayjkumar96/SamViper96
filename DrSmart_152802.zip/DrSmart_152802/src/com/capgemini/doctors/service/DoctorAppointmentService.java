package com.capgemini.doctors.service;

import java.util.InputMismatchException;

import com.capgemini.doctors.bean.DoctorAppointment;
import com.capgemini.doctors.dao.DoctorAppointmentDao;
import com.capgemini.doctors.exception.DrSmartException;

public class DoctorAppointmentService implements IDoctorAppointmentService {

	DoctorAppointmentDao dao = new DoctorAppointmentDao();
	static String namePattern = "[A-Z]{1}[a-z]{2,}";
	 static String numberPattern = "(\\d){10}";
	// static String emailPattern = "(\\w){3,}[\\W]{1,2}";
	 
	enum genderPattern {male,female};
	private genderPattern gender;
	
	
	@Override
	public int addDoctorAppoinmtmentDetails(DoctorAppointment doctorAppointment) {
		
		if(doctorAppointment.getProblemName().equalsIgnoreCase("heart"))
		{
			doctorAppointment.setDoctorName("Dr. Brijesh Kumar");
			doctorAppointment.setAppointementStatus("APPROVED");
		}
		else if(doctorAppointment.getProblemName().equalsIgnoreCase("gynecology"))
		{
			doctorAppointment.setDoctorName("Dr. Sharada Singh");
			doctorAppointment.setAppointementStatus("APPROVED");
		}
		else if(doctorAppointment.getProblemName().equalsIgnoreCase("diabetes"))
		{
			doctorAppointment.setDoctorName("Dr. Heena Khan");
		doctorAppointment.setAppointementStatus("APPROVED");
		}
		else if(doctorAppointment.getProblemName().equalsIgnoreCase("ent")){
			
			doctorAppointment.setDoctorName("Dr. Paras mal");
			doctorAppointment.setAppointementStatus("APPROVED");
		}
		else if(doctorAppointment.getProblemName().equalsIgnoreCase("bone")) {
			
			doctorAppointment.setDoctorName("Dr. Renuka Kher");
			doctorAppointment.setAppointementStatus("APPROVED");
		}
		else if(doctorAppointment.getProblemName().equalsIgnoreCase("dermatology")) {
			
			doctorAppointment.setDoctorName("Dr. Kanika Kapoor");
			doctorAppointment.setAppointementStatus("APPROVED");
		}
		else
		{
			doctorAppointment.setDoctorName(null);
			doctorAppointment.setAppointementStatus("DISAPPROVED");
		}
		return dao.addDoctorAppoinmtmentDetails(doctorAppointment);
	}

	@Override
	public DoctorAppointment getDoctorAppointmentDetails(int appointmentId) throws DrSmartException {
		
		return dao.getDoctorAppointmentDetails(appointmentId);
	}
	
	
	public  boolean validateName(String name)
	{	if(name.matches(namePattern))
			return true;
		else
			return false;
		
	}
	public  boolean validatePhoneNumber(String number) {
		if(number.matches(numberPattern))
			return true;
		else
			return false;
	}

	public boolean validateAge(int age) {
		if(age<=110&&age>=1)
			return true;
		else
			return false;
		
	}
	public boolean validateEmail(String email){
		if(email.endsWith(".com"))
			return true;
		else
			return false;
		
	}
	public boolean validateGender(String gender) throws DrSmartException {
		try {
			this.gender = genderPattern.valueOf(gender);
			return true;
		}
		catch(IllegalArgumentException e ) {
			throw new DrSmartException("Incorrect gender");
		}
}
	
	
	
	
	
}