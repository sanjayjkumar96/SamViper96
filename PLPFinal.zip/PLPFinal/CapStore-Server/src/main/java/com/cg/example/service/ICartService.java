package com.cg.example.service;

import com.cg.example.beans.Cart;
import com.cg.example.beans.Product;


public interface ICartService {
	
	public Product addCartItem(int pid,int custid);
	
	public void addCart(int custid);
	
	public void removeCartItem(int pid,int custid);
	
	public Cart viewCart(int custid);
	
	public Boolean minAmountCheck(int custid);

	
}
