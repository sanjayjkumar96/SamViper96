package com.project.wallet.dao;

import java.util.List;

import com.project.wallet.entity.Account;
import com.project.wallet.entity.TDetails;
import com.project.wallet.exception.WalletException;

public interface IWalletDBAccess {

int accCreation(Account a) throws WalletException;
	
	Account loginUser(int accNo) throws WalletException;
	
	void updateDetails(int accNo, Account a) throws WalletException;
	
	List<TDetails> fetchTransaction(int accNum) throws WalletException;
	
}
