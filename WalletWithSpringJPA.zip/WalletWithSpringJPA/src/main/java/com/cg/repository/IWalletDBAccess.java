package com.cg.repository;

import java.util.List;

import com.cg.entity.Account;
import com.cg.entity.TDetails;
import com.cg.exception.WalletException;

public interface IWalletDBAccess {

int accCreation(Account a) throws WalletException;
	
	Account loginUser(int accNo) throws WalletException;
	
	void updateDetails(int accNo, Account a) throws WalletException;
	
	List<TDetails> fetchTransaction(int accNum) throws WalletException;
	
}
